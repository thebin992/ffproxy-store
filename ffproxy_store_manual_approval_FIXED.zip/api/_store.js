// api/_store.js
const BASE = process.env.UPSTASH_REDIS_REST_URL;
const TOKEN = process.env.UPSTASH_REDIS_REST_TOKEN;
async function redis(command, ...args){
  if(!BASE || !TOKEN) throw new Error('Thiếu UPSTASH_REDIS_REST_URL hoặc UPSTASH_REDIS_REST_TOKEN');
  const r=await fetch(BASE,{method:'POST',headers:{Authorization:`Bearer ${TOKEN}`,'Content-Type':'application/json'},body:JSON.stringify([command,...args])});
  const j=await r.json();
  if(!r.ok || j.error) throw new Error(j.error||'Redis error');
  return j.result;
}
async function readJson(key, fallback=[]){ const raw=await redis('GET',key); if(!raw)return fallback; try{return JSON.parse(raw)}catch{return fallback} }
async function writeJson(key,value){await redis('SET',key,JSON.stringify(value)); return value;}
module.exports={redis,readJson,writeJson};
