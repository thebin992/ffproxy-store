const {readJson,writeJson}=require('./_store');
function json(res,status,body){res.status(status).json(body)}
function now(){return new Date().toISOString()}
const REQ='ff:topup:requests'; const CRED='ff:topup:credits';
module.exports=async function handler(req,res){
 if(req.method!=='POST')return json(res,405,{ok:false,error:'POST only'});
 try{
  const action=req.body?.action;
  let requests=await readJson(REQ,[]);
  let credits=await readJson(CRED,[]);
  if(action==='list') return json(res,200,{ok:true,requests});
  if(action==='create'){
   const r=req.body.request;
   if(!r?.id||!r?.user_email||!(Number(r.amount)>0)||!r.note)return json(res,400,{ok:false,error:'Invalid request'});
   if(!requests.some(x=>x.id===r.id)) requests.push({...r,status:'pending'});
   await writeJson(REQ,requests);
   return json(res,200,{ok:true,request:requests.find(x=>x.id===r.id)});
  }
  if(action==='credits'){
   const email=String(req.body.email||'').toLowerCase();
   return json(res,200,{ok:true,credits:credits.filter(c=>!c.consumed&&String(c.user_email).toLowerCase()===email)});
  }
  if(action==='consume_credits'){
   const email=String(req.body.email||'').toLowerCase();
   const ids=Array.isArray(req.body.credit_ids)?req.body.credit_ids:[];
   credits=credits.map(c=>!c.consumed&&String(c.user_email).toLowerCase()===email&&ids.includes(c.id)?{...c,consumed:true,consumed_at:now()}:c);
   await writeJson(CRED,credits);
   return json(res,200,{ok:true});
  }
  // Không cho phép duyệt/từ chối từ frontend; chỉ SePay webhook được phép cấp credit.
  if(action==='approve'||action==='reject') return json(res,403,{ok:false,error:'Manual approval disabled; use SePay webhook'});
  return json(res,400,{ok:false,error:'Unknown action'});
 }catch(e){return json(res,500,{ok:false,error:e.message})}
}
