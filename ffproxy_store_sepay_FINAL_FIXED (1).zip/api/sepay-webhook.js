const crypto=require('crypto');
const {readJson,writeJson}=require('./_store');
function json(res,status,body){res.status(status).json(body)}
function now(){return new Date().toISOString()}
const REQ='ff:topup:requests', CRED='ff:topup:credits', EVT='ff:sepay:events';

// Vercel must receive the exact raw request body for HMAC verification.
module.exports.config={api:{bodyParser:false}};
function readRawBody(req){return new Promise((resolve,reject)=>{let data=[];req.on('data',c=>data.push(Buffer.isBuffer(c)?c:Buffer.from(c)));req.on('end',()=>resolve(Buffer.concat(data)));req.on('error',reject)})}
function safeEqual(a,b){const x=Buffer.from(a),y=Buffer.from(b);return x.length===y.length&&crypto.timingSafeEqual(x,y)}

module.exports=async function handler(req,res){
 if(req.method!=='POST')return json(res,405,{success:false,message:'POST only'});
 try{
  const raw=await readRawBody(req);
  const timestamp=String(req.headers['x-sepay-timestamp']||'');
  const signature=String(req.headers['x-sepay-signature']||'');
  const secret=process.env.SEPAY_WEBHOOK_SECRET||'';
  if(!secret||!timestamp||!signature)return json(res,401,{success:false,message:'Missing HMAC headers'});
  const ts=Number(timestamp);
  if(!Number.isFinite(ts)||Math.abs(Math.floor(Date.now()/1000)-ts)>300)return json(res,401,{success:false,message:'Expired timestamp'});
  const expected='sha256='+crypto.createHmac('sha256',secret).update(timestamp+'.').update(raw).digest('hex');
  if(!safeEqual(expected,signature))return json(res,401,{success:false,message:'Invalid signature'});
  const p=JSON.parse(raw.toString('utf8'));
  const eventId=String(p.id||'');
  const account=String(p.accountNumber||'');
  const type=String(p.transferType||'').toLowerCase();
  const amount=Number(p.transferAmount||0);
  const content=String(p.content||'');
  if(!eventId||amount<=0||type!=='in')return json(res,200,{success:true,message:'Ignored'});
  if(process.env.BANK_ACCOUNT_NUMBER&&account!==process.env.BANK_ACCOUNT_NUMBER)return json(res,200,{success:true,message:'Ignored account'});
  const events=await readJson(EVT,[]);
  if(events.some(e=>String(e.id)===eventId))return json(res,200,{success:true,message:'Already processed'});
  const requests=await readJson(REQ,[]);
  const normalized=content.toUpperCase().replace(/\s+/g,'');
  const i=requests.findIndex(r=>r.status==='pending'&&Number(r.amount)===amount&&normalized.includes(String(r.note||'').toUpperCase().replace(/\s+/g,'')));
  if(i<0){events.push({id:eventId,status:'unmatched',amount,content,received_at:now()});await writeJson(EVT,events);return json(res,200,{success:true,message:'No matching pending topup'});}
  const credits=await readJson(CRED,[]);
  const r=requests[i];
  requests[i]={...r,status:'approved',reviewed_date:now(),approved_by:'sepay_webhook',sepay_event_id:eventId};
  if(!credits.some(c=>c.topup_id===r.id))credits.push({id:'CR'+Date.now()+Math.random().toString(16).slice(2),topup_id:r.id,user_email:r.user_email,amount,created_at:now(),consumed:false});
  events.push({id:eventId,status:'approved',topup_id:r.id,amount,content,received_at:now()});
  await writeJson(REQ,requests);await writeJson(CRED,credits);await writeJson(EVT,events);
  return json(res,200,{success:true,message:'Payment approved',topup_id:r.id,amount});
 }catch(e){return json(res,500,{success:false,message:e.message})}
}
